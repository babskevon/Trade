from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import *
# Register your models here.
class Notify(admin.ModelAdmin):
	list_display = ('mssg','create','status')
	list_filter = ('mssg',)
	search_fields = ['mssg','create']
class InvestAdmin(admin.ModelAdmin):
	list_display 	= ('investor','initial', 'expected','create','expire','status')
	list_filter		= ("initial",)
	search_fields 	= ['investor', 'initial']

class CompanyList(admin.ModelAdmin):
	list_display 	= ('name','address','email','contact','about')
	list_filter 	= ('name',)
	search_fields 	= ['name']

class BioDataL(admin.ModelAdmin):
	list_display	= ('member','occupation','address','kin','kinContact')
	list_filter		= ('member',)
	search_fields 	= ['member','occupation']

class Text(admin.ModelAdmin):
	list_display 	= ('user','text')
	list_filter		= ('user',)
	search_fields 	= ['user']
class Mssg(admin.ModelAdmin):
	list_display = ('name','contact','subject','mssg','status','create')
	list_filter = ('name',)
	search_fields = ['name']
admin.site.register(User, UserAdmin)
admin.site.register(Invest,InvestAdmin)
admin.site.register(Company, CompanyList)
admin.site.register(Biodata, BioDataL)
admin.site.register(Testmonial,Text)
admin.site.register(Message,Mssg)
admin.site.register(Notification,Notify)