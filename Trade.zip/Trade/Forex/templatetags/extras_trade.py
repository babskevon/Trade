from django import template
from django.template.defaultfilters import stringfilter
from datetime import *
from Forex.models import *

register = template.Library()
@register.filter()
@stringfilter
def test(value,arg="muted"):
	return "Kevin"

@register.filter()
def exp(value,arg="muted"):
	return value*2

@register.filter()
def daily(value,arg):
	total = value * 2
	create		= arg.date()
	today 		= datetime.now().date()
	if((today-create).days ==0):
		return "Pending..."
	elif((today-create).days >= 60):
		return 'none...'
	else:
		return "{:,}".format(int(total/60))
		# data = int(total/60)
	# return data

@register.filter()
def total(value,arg):
	create = value.date()#datetime.strptime(str(value),"%Y-%m-%d").date()
	today  = datetime.now().date()
	base   = (today - create).days
	if(base< 60 and base>0):
		daily	= (arg*2)/60
		profit  = daily * base
		current =  profit
		return "{:,}".format(int(current))
	elif(base >= 60):
		current = arg*2
		return "{:,}".format(int(current))
	else:
		return "Pending..."
@register.filter()
def status(value,arg="muted"):
	create   = value.date()
	today    = datetime.now().date()
	valid	 = (today - create).days
	if(valid>60):
		data = "inactive | 60 days"
	else:
		data = "active | {} days".format(valid)
	return data

@register.filter()
def account(value,arg="muted"):
	alpha = ['2','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']
	return alpha[value]
	# if(value==1):
	# 	data = "A"
	# else:
	# 	data = "B"
	# return data

@register.filter()
def numClients(value,arg):
	return value[int(arg)]

@register.filter()
def cash(value,arg="muted"):
	# mylist = []
	# for my in str(int(value[int(arg)])):
	# 	mylist.append(my)
	# for l in range(len(mylist)):
	# 	k = '300'+str(mylist[l])
	# k = str(int(value[int(arg)])).split('')

	return "{:,}".format(int(value))

@register.filter()
def statusAdmin(value,arg='muted'):
	create   = value.date()
	today    = datetime.now().date()
	valid	 = (today - create).days
	if(valid>=60):
		return "Inactive"
	else:
		return "active"
@register.filter()
def update(value,arg):
	create = value.date()
	today = datetime.now().date()
	differ = (today-create).days
	if(differ>60 or differ==60):
		data = Invest.objects.get(id=arg)
		if(data.status==True):
			data.status = False
			data.save()
			return 'success'
		else:
			return 'success'
	else:
		pass
@register.filter()
def cash2(value,arg):
	return "{:,}".format(int(value[int(arg)]))

@register.filter()
def expire(value,arg="muted"):
	initial = value.date()
	return (initial+timedelta(days=60))

@register.filter()
def mydate(value,arg="muted"):
	return value.date()

@register.filter()
def notify(value,arg="muted"):
	if(value<=5):
		return value
	else:
		new = value % 5
		return "{}".format(new)
	# return "2"
@register.filter()
def status2(value,arg="muted"):
	if(value==True):
		return "Unread"
	else:
		return 'Read'