from django.db import models
from django.contrib.auth.models import AbstractUser
from datetime import *
# Create your models here.
# def exp(today):
# 	actual = today + timedelta(days=60)
# 	return actual

# pp = exp(datetime.now())

class User(AbstractUser):
	contact 	= models.CharField(max_length=25)
	REQUIRED_FIELDS = ['contact']

class Biodata(models.Model):
	member 		= models.ForeignKey(User,on_delete=models.CASCADE)
	occupation 	= models.CharField(max_length=25)
	address 	= models.CharField(max_length=150)
	kin 		= models.CharField(max_length=35)
	kinContact	= models.CharField(max_length=25)


class Invest(models.Model):
	investor 	= models.ForeignKey(User,on_delete=models.CASCADE)
	initial 	= models.DecimalField(max_digits=65,decimal_places=2)
	expected 	= models.DecimalField(max_digits=65,decimal_places=2)
	create 		= models.DateTimeField(auto_now=False)
	expire 		= models.DateTimeField()
	status		= models.BooleanField(default=True)

class Company(models.Model):
	name		= models.CharField(max_length=30)
	address 	= models.CharField(max_length=150)
	email		= models.CharField(max_length=50)
	contact 	= models.CharField(max_length=50)
	about 		= models.TextField(blank=True,null=True)

class Testmonial(models.Model):
	user 	= models.ForeignKey(User,on_delete=models.CASCADE)
	text 	= models.TextField()

	class Meta:
		ordering = ['-id']
class Message(models.Model):
	name = models.CharField(max_length=50)
	contact = models.CharField(max_length=15)
	subject = models.CharField(max_length=100)
	mssg = models.TextField()
	create = models.DateTimeField(auto_now=False)
	status = models.BooleanField(default=True)

	class Meta:
		ordering = ['-status','-create']

class Notification(models.Model):
	mssg = models.CharField(max_length=30)
	create = models.DateTimeField(auto_now=True)
	status = models.BooleanField(default=False)

	class Meta:
		ordering = ['-status','-create']