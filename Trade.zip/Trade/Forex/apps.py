from django.apps import AppConfig


class ForexConfig(AppConfig):
    name = 'Forex'
