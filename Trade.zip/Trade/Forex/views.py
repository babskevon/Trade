from django.shortcuts import render,redirect
from django.contrib.auth import login, authenticate,get_user_model, logout
from .models import *
from django.http import HttpResponse
from datetime import *

# Create your views here.
def indexV(request):
	if request.method=='POST':
		contact = request.POST.get('contact')
		if(len(contact)==13 or len(contact)==10):
			try:
				Notification.objects.create(mssg=contact)
				return HttpResponse(1)
			except:
				return HttpResponse('Unable to reach server, please send contact again')
		else:
			return HttpResponse('Please make sure you have entered the right contact')
	if request.user.is_authenticated:
		return redirect("/Profile/")
	company = Company.objects.all()
	data = {
		'page':'Home',
		'active1':'active',
		'company':company,

	}
	return render(request,"index.html",data)

def contactV(request):
	if request.method=='POST':
		name = request.POST.get('name')
		contact = request.POST.get('email')
		subject = request.POST.get('subject')
		mssg = request.POST.get('mssg')
		try:
			Message.objects.create(name=name,contact=contact,subject=subject,mssg=mssg,create=datetime.now())
			return HttpResponse(1)
		except:
			return HttpResponse(0)
	if request.user.is_authenticated:
		return redirect("/Profile/")
	company = Company.objects.all()
	data = {
		'page':'Contact',
		'active2':'active',
		'company':company,
	}
	return render(request,"contact.html",data)

def aboutV(request):
	company = Company.objects.all()
	test 	= Testmonial.objects.all()[:4]
	data = {
		'page':'About Us',
		'active3':'active',
		'company':company,
		'test':test,
	}
	return render(request,"about.html",data)

def loginV(request):
	message = ''
	if request.method == 'POST':
		username = request.POST.get('username')
		password = request.POST.get('password')
		user = authenticate(username=username, password=password)
		try:
			login(request,user)
			if(request.user.is_staff):
				return redirect('/Admin/')
			else:
				return redirect('/Profile/')
		except:
			message = 'Enter right credentials'
	data = {'message':message}
	return render(request,"login.html",data)
def profileV(request):
	if request.user.is_authenticated:
		if(request.user.is_staff):
			return redirect('/Admin/')
		else:
			pass
	else:
		return redirect('/')
	company = Company.objects.all()
	biodata = Biodata.objects.get(member=request.user)
	invest 	= Invest.objects.filter(investor=request.user)
	data = {
		'page':'Profile',
		'company':company,
		'biodata':biodata,
		'invest':invest,
	}
	return render(request,"profile.html",data)


def adminV(request):
	if request.user.is_authenticated:
		if(request.user.is_staff):
			pass
		else:
			return redirect('/Profile/')
	else:
		return redirect('/')
	statics = []
	investment = 0
	profit = 0
	client = User.objects.exclude(is_superuser=True).count()
	statics.append(client)
	active = Invest.objects.filter(status=True).count()
	statics.append(active)
	total  = User.objects.filter(is_active=True).count()
	statics.append(total)
	try:
		for value in Invest.objects.all():
			investment = investment + value.initial
			profit = profit + (value.initial * 2)
		statics.append(investment)
		statics.append(profit)
	except:
		statics.append(investment)
		statics.append(profit)
		pass
	mssd = Message.objects.filter(status=True)
	notification = Notification.objects.filter(status=True)
	data = {
		'page':'Dashboard',
		'statics':statics,
		'mssd':mssd,
		'count':mssd.count(),
		'notification':notification,
		'countN':notification.count(),
	}
	return render(request,"admin1/index.html",data)

def adminUserV(request):
	if request.user.is_authenticated:
		if(request.user.is_staff):
			pass
		else:
			return redirect('/Profile/')
	else:
		return redirect('/')
	users = Biodata.objects.exclude(member__is_staff=True)
	mssd = Message.objects.filter(status=True)
	notification = Notification.objects.filter(status=True)
	data = {
		'page':'Users',
		'title':'Users / Clients',
		'Users':users,
		'mssd':mssd,
		'count':mssd.count(),
		'countN':notification.count(),
		'notification':notification,
		# 'create':'../../Accounts/Create',
	}
	return render(request,"admin1/users.html",data)
def adminUserAdmin(request):
	if request.user.is_authenticated:
		if(request.user.is_staff):
			pass
		else:
			return redirect('/Profile/')
	else:
		return redirect('/')
	users = User.objects.filter(is_staff=True)
	mssd = Message.objects.filter(status=True)
	notification = Notification.objects.filter(status=True)
	data = {
		'page':'Users',
		'title':'Users / Admins',
		'Users':users,
		'mssd':mssd,
		'count':mssd.count(),
		'countN':notification.count(),
		'notification':notification,
	}
	return render(request,"admin1/users-admin.html",data)
def addClient(request):
	if request.user.is_authenticated:
		if(request.user.is_staff):
			pass
		else:
			return redirect('/Profile/')
	else:
		return redirect('/')
	if request.method == 'POST':
		fname 	= request.POST.get('fname')
		lname 	= request.POST.get('lname')
		occupy 	= request.POST.get('occupy')
		tel 	= request.POST.get('tel')
		kin		= request.POST.get('kin')
		kin_tel	= request.POST.get('kin_tel')
		username= request.POST.get('username')
		email 	= request.POST.get('email')
		password= request.POST.get('password')
		address = request.POST.get('address')
		try:
			user = User.objects.create_user(username=username,password=password,email=email,contact=tel,first_name=fname,last_name=lname)
			Biodata.objects.create(member=user,occupation=occupy,kin=kin,kinContact=kin_tel,address=address)
			return HttpResponse('{} added successfully'.format(user)) 
		except:
			return HttpResponse('user not added')
			# pass
	mssd = Message.objects.filter(status=True)
	notification = Notification.objects.filter(status=True)
	data = {
		'page':'Users',
		'title':'Users / Add / Client',
		'mssd':mssd,
		'count':mssd.count(),
		'countN':notification.count()
	}
	return render(request,"admin1/add-client.html",data)
def addAdmin(request):
	if request.user.is_authenticated:
		if(request.user.is_staff):
			pass
		else:
			return redirect('/Profile/')
	else:
		return redirect('/')
	if request.method == 'POST':
		username 	= request.POST.get('username')
		fname 		= request.POST.get('fname')
		lname 		= request.POST.get('lname')
		staff 		= request.POST.get('staff')
		tel 		= request.POST.get('tel')
		email 		= request.POST.get('email')
		password 	= request.POST.get('password')
		try:
			if(staff=="Admin"):
				user = User.objects.create_user(username=username,first_name=fname,last_name=lname,email=email,contact=tel,password=password)
				user.is_superuser = True
				user.is_staff = True
				user.save()
				return HttpResponse(1)
			else:
				user = User.objects.create_user(username=username,first_name=fname,last_name=lname,email=email,contact=tel,password=password)
				user.is_staff = True
				user.save()
				return HttpResponse(1)
		except:
			return HttpResponse(0)
	mssd = Message.objects.filter(status=True)
	notification = Notification.objects.filter(status=True)
	data = {
		'page':'Users',
		'title':'Users / Add / Admin',
		'mssd':mssd,
		'count':mssd.count(),
		'notification':notification,
		'countN':notification.count(),
	}
	return render(request,"admin1/add-admin.html",data)

def accountV(request):
	if request.user.is_authenticated:
		if(request.user.is_staff):
			pass
		else:
			return redirect('/Profile/')
	else:
		return redirect('/')
	if request.method == 'POST':
		name = request.POST.get('username')
		amount = request.POST.get('amount')
		expected = int(amount)*2
		expire = datetime.now() + timedelta(days=60)
		user = User.objects.get(first_name=name.split()[0],is_staff=False)
		try:
			new = Invest(investor=user,initial=int(amount),expected=expected,expire=expire,create=datetime.now())
			new.save()
			#Invest.objects.create(investor='kevon',initial=500000.00,expected=1000000.00)
			return HttpResponse(name+"'s account has been successfully created")
		except:
			return HttpResponse("Oops! Unable to create new account")

	accounts = Invest.objects.all()
	users    = User.objects.exclude(is_staff=True)
	mssd = Message.objects.filter(status=True)
	notification = Notification.objects.filter(status=True)
	data = {
		'page':'Account',
		'title':'Accounts / View',
		'accounts':accounts,
		'users':users,
		'mssd':mssd,
		'count':mssd.count(),
		'countN':notification.count(),
		'notification':notification,
		# 'single':single,
	}
	return render(request,"admin1/view.html",data)
def detailV(request,id):
	if request.user.is_authenticated:
		if(request.user.is_staff):
			pass
		else:
			return redirect('/Profile/')
	else:
		return redirect('/')
	detail = Invest.objects.get(id=id)
	if request.method=='POST':
		inv = request.POST.get('inv')
		try:
			detail.initial = int(inv)
			detail.expected = int(inv)*2
			detail.save()
			return HttpResponse(detail.investor.username+' updated successfully')
		except:
			return HttpResponse('Unable to update account')
	mssd = Message.objects.filter(status=True)
	notification = Notification.objects.filter(status=True)
	data = {
		'page':'Account',
		'title':'Accounts / Details',
		'detail':detail,
		'id':id,
		'mssd':mssd,
		'count':mssd.count(),
		'countN':notification.count(),
		'notification':notification,
	}
	return render(request,"admin1/detail.html",data)
def logOut(request):
	logout(request)
	return redirect('/')


def delAcc(request,id):
	if request.user.is_authenticated:
		if(request.user.is_staff):
			pass
		else:
			return redirect('/Profile/')
	else:
		return redirect('/')
	data = Invest.objects.get(id=id)
	data.delete()
	return redirect('/Admin/Accounts/View/')

def mssg(request):
	if request.method=='POST':
		id1 = request.POST.get('id')
		mssg = Message.objects.get(id=id1)
		try:
			mssg.status = False
			mssg.save()
			return HttpResponse('successfully')
		except:
			return HttpResponse(id1)
	if request.user.is_authenticated:
		if(request.user.is_staff):
			pass
		else:
			return redirect('/Profile/')
	else:
		return redirect('/')

	mssgs = Message.objects.all()
	mssd = Message.objects.filter(status=True)
	notification = Notification.objects.filter(status=True)
	notifications = Notification.objects.all()
	data = {
		'page':'Messages',
		'title':'Messages',
		'mssgs':mssgs,
		'mssd':mssd,
		'count':mssd.count(),
		'countN':notification.count(),
		'notification':notification,
		'notifications':notifications,
	}

	return render(request,"admin1/mssg.html",data)
